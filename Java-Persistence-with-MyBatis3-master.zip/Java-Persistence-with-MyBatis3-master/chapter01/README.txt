Chapter 1: Getting started with MyBatis
=======================================
This module, chapter01, is a maven based java project with MyBatis configured.

How to Run:
	1. Create MySQL Database tables using scripts in src/main/resources/sql folder.
	2. Configure Database Connection properties like hostname, username and password in src/main/resources/application.properties file.
	3. Run StudentServiceTest JUnit Test class.